//
// Created by Zunaira on 12/05/2024.
//

#include "Reading.h"

void Reading::readingData() {
    int assignmentCount = 0;
    int quizCount = 0;
    int midtermCount = 0;
    int finalCount = 0;
    int projectCount = 0;
    int plagrismCount = 0;
    json course;
    ifstream courseFile("course.json");
    if (courseFile.is_open()) {
        courseFile >> course;
        course["components"]["assignment"]["total"] = assignmentCount;
        course["components"]["quiz"]["total"] = quizCount;
        course["components"]["project"]["total"] = projectCount;
        course["components"]["midterm"]["total"] = midtermCount;
        course["components"]["final"]["total"] = finalCount;
        courseFile.close();
    }
    int n = 1;
    for (int i = 0; i < 10; i++) {
        string rollno = "BSSE2x00" + to_string(n);
        json j;
        for (int z = 0; z < assignmentCount; z++) {
            int num = 1;
            string assignmentFiles = "assignment" + to_string(num) + ".json";
            ifstream assignment(assignmentFiles);
            if (assignment.is_open()) {
                assignment >> j;
                j["rollNo"] = rollno;
                if (j["plagiarism"] == true) {
                    plagrismCount++;
                }
                assignment.close();
            } else {
                cout << "File isn't opening\n";
            }
        }
        json js;
        for (int z = 0; z < quizCount; z++) {
            int num = 1;
            string quizFiles = "quiz" + to_string(num)+".json";
            cout << quizFiles<<endl;
            num++;
            ifstream quiz(quizFiles);
            if (quiz.is_open()) {
                quiz >> js;
                j["rollNo"] = rollno;
                if (j["plagiarism"] == true) {
                    plagrismCount++;
                }
                quiz.close();
            }
        }
        json jso;
        ifstream mid("midterm1.json");
        if (mid.is_open()) {
            mid >> jso;
            j["rollNo"] = rollno;
            if (j["plagiarism"] == true) {
                plagrismCount++;
            }
            mid.close();
        }
        json json1;
        ifstream final("final1.json");
        if (final.is_open()) {
            final >> json1;
            j["rollNo"] = rollno;
            if (j["plagiarism"] == true) {
                plagrismCount++;
            }
            final.close();
        }
        json json2;
        ifstream project("project1.json");
        if (project.is_open()) {
            project >> json2;
            j["rollNo"] = rollno;
            if (j["plagiarism"] == true) {
                plagrismCount++;
            }
            project.close();
        }
        n++;
    }
}