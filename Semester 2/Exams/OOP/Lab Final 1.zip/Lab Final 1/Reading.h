//
// Created by Zunaira on 12/05/2024.
//

#ifndef INC_2024_SPRING_SE102LA_WEEK16_BSSE23058_READING_H
#define INC_2024_SPRING_SE102LA_WEEK16_BSSE23058_READING_H

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "nlohmann/json.hpp"

using namespace std;
using json = nlohmann::json;

class Reading {
private:
public:
    void readingData();
};


#endif //INC_2024_SPRING_SE102LA_WEEK16_BSSE23058_READING_H
