//
// Created by Zunaira on 13/05/2024.
//

#include "Writing.h"

void Writing::writingData() {
    int assignmentCount=0;
    int quizCount=0;
    int midtermCount=0;
    int finalCount=0;
    int projectCount=0;
    int marks=0,total=0;
    bool pledge;
    json course;
    ifstream courseFile("course.json");
    if(courseFile.is_open()){
        courseFile>>course;
        course["components"]["assignment"]["total"]=assignmentCount;
        course["components"]["quiz"]["total"]=quizCount;
        course["components"]["project"]["total"]=projectCount;
        course["components"]["midterm"]["total"]=midtermCount;
        course["components"]["final"]["total"]=finalCount;
    }
    int n=0;
    for(int i=0; i<10; i++ ){
        string rollno = "BSSE2x00" + to_string(n);
        json j;
        for (int z = 0; z < assignmentCount; z++) {
            int num = 1;
            string assignmentFiles = "assignment" + to_string(num)+ ".json";
            ifstream assignment(assignmentFiles);
            if (assignment.is_open()) {
                assignment >> j;
                j["rollNo"]=rollno;
                j["marks"] =marks;
                j["total"]=total;
                j["plagiarism"]=pledge;
                assignment.close();
            }else{
                cout << "File isn't opening\n";
            }
            json array;
            array["rollNo"]={
                    {"marks",marks},
                    {"total", total},
                    {"plagiarism",pledge}
            };
            ofstream assign(assignmentFiles);
            if(assign.is_open()){
                assign << array.dump(4) << endl;
            }
            assign.close();
            json js;
            for (int z = 0; z < quizCount; z++) {
                int num = 1;
                string quizFiles = "quiz" + to_string(num)+".json";
                num++;
                ifstream quiz(quizFiles);
                if (quiz.is_open()) {
                    quiz >> js;
                    quiz.close();
                }
            }
            json jso;
            ifstream mid("midterm1.json");
            if (mid.is_open()) {
                mid >> jso;
                mid.close();
            }
            json json1;
            ifstream final("final1.json");
            if (final.is_open()) {
                final >> json1;
                final.close();
            }
            json json2;
            ifstream project("project1.json");
            if (project.is_open()) {
                project >> json2;
                project.close();
            }
        }
        n++;
    }
}

//void Writing::test() {
//    int assignmentCount = 0;
//    int quizCount = 0;
//    int midtermCount = 0;
//    int finalCount = 0;
//    int projectCount = 0;
//    int plagrismCount = 0;
//    json course;
//    ifstream courseFile("course.json");
//    if (courseFile.is_open()) {
//        courseFile >> course;
//        course["components"]["assignment"]["total"] = assignmentCount;
//        course["components"]["quiz"]["total"] = quizCount;
//        course["components"]["project"]["total"] = projectCount;
//        course["components"]["midterm"]["total"] = midtermCount;
//        course["components"]["final"]["total"] = finalCount;
//        courseFile.close();
//    }
//    int n = 1;
//    for (int i = 0; i < 10; i++) {
//        string rollno = "BSSE2x00" + to_string(n);
//        json j;
//        for (int z = 0; z < assignmentCount; z++) {
//            int num = 1;
//            string assignmentFiles = "assignment" + to_string(num) + ".json";
//            ifstream assignment(assignmentFiles);
//            if (assignment.is_open()) {
//                assignment >> j;
//                j["rollNo"] = rollno;
//                if (j["plagiarism"] == true) {
//                    plagrismCount++;
//                }
//                assignment.close();
//            } else {
//                cout << "File isn't opening\n";
//            }
//        }
//    json jo;
//    jo["rollNo"] = rollno;
//    ofstream file("json.json");
//    if(file.is_open()){
//        file << setw(4) << j << endl;
//    }else{
//        cout << "File isnt code\n";
//    }
//}}