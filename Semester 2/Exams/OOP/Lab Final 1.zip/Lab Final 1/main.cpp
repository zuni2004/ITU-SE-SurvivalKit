#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Reading.h"
#include "Writing.h"
#include "nlohmann/json.hpp"

using namespace std;
using json = nlohmann::json;

int main() {
    int choice;
    Reading reading;
    Writing writing;
    do {
        cout << "1. Read Data from the JSON\n";
        cout << "2. Get Plagiarism Stats\n";
        cout << "3. Get Result with all componenets\n";
        cout << "4. Get result with the best Policy\n";
        cout << "5. Write a new format of JSON\n";
        cout << "6. Exit\n";
        cin >> choice;
        switch (choice) {
            case 1: {
                reading.readingData();
                break;
            }
            case 2: {
                reading.readingData();
                break;
            }
            case 3: {
//                writing.test();
                break;
            }
            case 4: {

                break;
            }
            case 5: {
                writing.writingData();
                break;
            }
            case 6: {
                cout << "Exiting.....\n";
                break;
            }
        }
    } while (choice != 6);
    return 0;
}
