#include "functions.h"
#include <cmath>

// Vector functions
Vector::Vector(double xVal, double yVal, double zVal) : x(xVal), y(yVal), z(zVal) {

}
double Vector::dotProduct(const Vector& other) const {
    return x * other.x + y * other.y + z * other.z;
//Write your logic here
}

Vector Vector::crossProduct(const Vector& other) const {
//Write your logic here
    double X = y * other.z - z * other.y;
    double Y = z * other.x - x * other.z;
    double Z = x * other.y - y * other.x;
    return Vector(X, Y, Z);
}

Vector::~Vector(){

}

Circle::~Circle(){

}

Circle::Circle(double diameter) {
  this->geometry.radius=diameter/2;
//Write your logic here
}

double Circle::calculateCircumference() const {
//Write your logic here
 return (2.0 * M_PI * geometry.radius);
}
