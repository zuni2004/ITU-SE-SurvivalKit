#ifndef FUNCTIONS_H
#define FUNCTIONS_H
#include <cmath>
#include <iostream>

struct Vector {
    double x, y, z;
    Vector(double xVal, double yVal, double zVal);// Constructor with parameters
    // Function to compute the dot product of two vectors
    double dotProduct(const Vector& other) const;
    // Function to compute the cross product of two vectors
    Vector crossProduct(const Vector& other) const;
    ~Vector();
};
struct Circle {
    struct Geometry {
        double radius;
    };
    Geometry geometry;
    Circle(double diameter);// Constructor with parameters
    // Function to calculate the circumference of the circle
    double calculateCircumference() const;
    ~Circle();
};

#endif // FUNCTIONS_H
