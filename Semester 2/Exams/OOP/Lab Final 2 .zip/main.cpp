#include "functions.h"
#include <iostream>
using namespace std;
int main() {
    int n;
    cout<<"enter q no."<<endl;
    cin>>n;
    switch(n){
        case 1:{
            int q1;
            cout<<"chose ur choice"<<endl;
            cout<<"1. dot product"<<endl;
            cout<<"2. cross product"<<endl;
            cin>>q1;
            switch(q1){
                case 1:{
                    Vector v1(1.0, 2.0, 3.0);
                    Vector v2(4.0, 5.0, 6.0);
                    double result = v1.dotProduct(v2);
                    cout << "dot product= " << result <<endl;
                    break;
                }
                case 2:{
                    Vector v1(1.0, 2.0, 3.0);
                    Vector v2(4.0, 5.0, 6.0);
                    Vector result = v1.crossProduct(v2);
                    cout << "cross product= (" << result.x << ", " << result.y <<
                    ", " << result.z << ")" <<endl;
                    break;
                }
            }
            break;
        }
        case 2:{
            Circle circle(4.0);
            cout << "circumference= " << circle.calculateCircumference() << endl;
            break;
        }
        default:{
            cout<<"invalid"<<endl;
            break;
        }
    }


    return 0;
}
